This is the memory safety proof for IsDCHPSocket.
