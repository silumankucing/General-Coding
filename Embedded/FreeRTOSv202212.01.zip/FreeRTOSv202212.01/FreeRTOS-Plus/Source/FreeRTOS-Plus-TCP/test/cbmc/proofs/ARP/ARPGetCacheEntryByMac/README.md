ARPGetCacheEntryByMac is memory safe,
if it is enabled.

ARPGetCacheEntryByMac does not use multiple configurations internally.
